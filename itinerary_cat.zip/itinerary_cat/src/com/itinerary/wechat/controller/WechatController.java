package com.itinerary.wechat.controller;

import com.itinerary.wechat.handler.ItWxHandler;
import com.itinerary.wechat.mp.vo.MPAct;
import com.itinerary.wechat.mp.web.WxSpringSupport;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;

@Controller("wxwechatController")
@RequestMapping(value = "/wxwechat")
public class WechatController extends WxSpringSupport {

	private Log logger = LogFactory.getLog(WechatController.class);

	@Value("${mp.weixin.appid}")
	protected String mpWeixinAppid;
	@Value("${mp.weixin.secret}")
	protected String mpWeixinSecret;

	private String token="weixincnsebe";

	private MPAct mpact;

	@Override
	protected void init() {
		if (mpact == null) {
			mpact = new MPAct();
			mpact.setAppId(mpWeixinAppid);
			mpact.setAppSecret(mpWeixinSecret);
			mpact.setToken(token);
		}
		this.setMpAct(mpact);
		// 可实现自己的WxHandler
		this.setWxHandler(new ItWxHandler());
	}

	/**
	 * 微信api专用（微信访问入口）
	 * 
	 * @param req
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "/core", produces = { "text/plain;charset=UTF-8" })
	public String wxCore(HttpServletRequest req) {
		String reply = "";
		try {
			 reply = wxInteract(req);
		} catch (Exception e) {
			logger.error(e.getLocalizedMessage(), e);
		}
		return reply;
	}


//	/**
//	 * 获取JSAPI签名
//	 *
//	 * @param url
//	 * @param session
//	 * @return
//	 */
//	@ResponseBody
//	@RequestMapping(value = HbConstant.V_URL_ROOT_WEIXIN + "/getJsAPISignByUrl", method = RequestMethod.GET)
//	public DtoResult getJsAPISignByUrl(@RequestParam("url") String url, HttpSession session) {
//		DtoResult re = new DtoResult();
//		try {
//			String mpid = session.getAttribute(HbConstant.S_SESSION_MPID).toString();
//			re = wexinService.getJsAPISignByUrl(mpid, url);
//			log.info("getJsAPISignByUrl.url=" + url);
//		} catch (Exception e) {
//			re.setCode(HbConstant.RESULT_CODE_FAILURE);
//			re.setResult(e);
//			log.error("getJsAPISignByUrl::" + e);
//		}
//		return re;
//	}



}
