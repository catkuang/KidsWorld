package com.itinerary.wechat.service;

/**
 * Created by HuangYc on 2016/11/16.
 */
public interface WeixinService {


}
