package com.itinerary.wechat.service.impl;

import org.springframework.stereotype.Service;

/**
 * 
 * @author Hasan
 *
 */
@Service("weixinService")
public class WeixinServiceImpl /*implements IWeixinService*/ {
//	private Log log = LogFactory.getLog(WeixinServiceImpl.class);
//
//
////	@Resource
////	private WxApi wxApi;
////
////	private Map<String, MPAct> mpacts;
//
////	@Override
//	@Transactional(value = "transactionManager", readOnly = true)
//	public void createMenu() throws Exception {
////		DtoResult re = new DtoResult();
////		String sql = "select x from Xmpmenu x where x.xmpmenu is null and x.xmpaccount.mpaccountid=" + mpaccountid
////				+ " and x.status =" + HbConstant.V_TRUE;
////		Xmpaccount mp = defaultDao.find(Xmpaccount.class, mpaccountid);
////		String host = "http://" + mp.getDns() + mp.getPageentry();
////		String url = "";
////		List<Menu> lsmenu = new ArrayList<Menu>();
////		List<Xmpmenu> lsx = defaultDao.findBySql(Xmpmenu.class, sql);
////		if (lsx != null && lsx.size() > 0) {
////			for (Xmpmenu x : lsx) {
////				// 一级
////				Menu menu = new Menu(x.getNamezh());
////				List<Menu> lsmenuson = new ArrayList<Menu>();
////				String sqlson = "select x from Xmpmenu x where x.xmpmenu.mpmenuid=" + x.getMpmenuid()
////						+ " and x.xmpaccount.mpaccountid=" + mpaccountid + " and x.status =" + HbConstant.V_TRUE;
////				List<Xmpmenu> lsxson = defaultDao.findBySql(Xmpmenu.class, sqlson);
////				if (lsxson != null && lsxson.size() > 0) {
////					for (Xmpmenu xson : lsxson) {
////						// 二级
////						url = String.format(WxApiUrl.WX_OPEN_API + WxApiUrl.WEB_OAUTH2, mp.getAppid(),
////								host + xson.getNameen(), "snsapi_base", mp.getMpid());
////						Menu menuson = new Menu(xson.getNamezh(), Menu.VIEW, url);
////						lsmenuson.add(menuson);
////					}
////				} else {
////					// TODO 加返回值基础数据
////					re.setCode("020003");
////					re.setResult("二级子菜单不能为空");
////					return re;
////				}
////				menu.setSubButtons(lsmenuson);
////				lsmenu.add(menu);
////			}
////		}
////		try {
////			if (lsmenu != null && lsmenu.size() > 0) {
////				wxApi.createMenu((Menu[]) lsmenu.toArray(new Menu[lsmenu.size()]));
////			}
////		} catch (Exception e) {
////			log.error("创建菜单失败::" + e);
////		}
////		return re;
//	}
//
//
////	@Override
//	public DtoWxPageAuthFailureResult getPageAuthAccessToken(String mpid, String code) throws Exception {
//		if (mpacts == null || mpacts.size() == 0) {
//			mpacts = mpaccountService.retrieveAllMpAccount();
//		}
//		// 网页授权获取TOKEN 没有限额
//		String url = String.format(WxApiUrl.WX_API_1 + WxApiUrl.OAUTH_TOKEN, mpacts.get(mpid).getAppId(),
//				mpacts.get(mpid).getAppSecret(), code);
//		String res = null;
//		try {
//			res = HttpUtils.get(url);
//			JSON.parseObject(res, DtoWxPageAuthSuccessResult.class);
//			log.info("getPageAuthAccessToken.result=" + res);
//		} catch (Exception e) {
//			log.error("getPageAuthAccessToken::刷新ACCESS_TOKEN时出现异常!!!" + e);
//		}
//
//		if (res.isEmpty() || res.contains("errcode")) {
//			DtoWxPageAuthFailureResult failureResult = JSON.parseObject(res, DtoWxPageAuthFailureResult.class);
//			result.setCode(HbConstant.RESULT_CODE_FAILURE);
//			result.setResult(failureResult);
//			log.info("getPageAuthAccessToken::" + failureResult.getErrmsg());
//		}
//
//		return result;
//	}
//
//	/*
//	 * (non-Javadoc)
//	 *
//	 * @see
//	 * com.xk.hb.service.intf.weixin.IWeixinService#getJsAPISignByUrl(java.lang
//	 * .String)
//	 */
////	@Override
//	public DtoResult getJsAPISignByUrl(String mpid, String url) throws Exception {
//		DtoResult re = new DtoResult();
//		// if (mpacts == null || mpacts.size() == 0) {
//		// mpacts = mpaccountService.retrieveAllMpAccount();
//		// }
//		// wxApi = new WxApiImpl(mpacts.get(mpid));
//		try {
//			Map<String, Object> config = mpaccountService.getJsAPISign(mpid, url);
//			re.setResult(config);
//			log.info("getJsAPISignByUrl.url=" + url);
//		} catch (WxRespException e) {
//			re.setCode(HbConstant.RESULT_CODE_FAILURE);
//			re.setResult(e);
//			log.error("getJsAPISignByUrl::" + e);
//		}
//		return re;
//	}
//
////	@Override
//	public DtoResult downloadimage(String mpid, String mediaId, String path, String filename, String type,
//			String mediatype) throws Exception {
//		DtoResult re = new DtoResult();
//		if (mediatype != null && mediatype.equals("1")) {// 音频
//			// 上传到微信的图片路径
//			String url = String.format(WxApiUrl.MEDIA_DL_API, mpaccountService.getAccessToken(mpid), mediaId);
//
//			File targetFile = new File(path);
//			SimpleHttpReq.download(url, targetFile);
//
//			String sourceurl = path;
//			String targetutl = path.replace(".amr", ".mp3");
//			targetutl = targetutl.replace(".wav", ".mp3");
//			String codec = "libmp3lame";
//			String format = "mp3";
//			ConvertUtil.convert(sourceurl, targetutl, codec, format);
//
//			wxaliyuncsService.uploadFile(filename, targetutl, type);
//
//			// 原始图删除
//			File orgtempfile = new File(path);
//			orgtempfile.delete();
//
//			File targetutlfile = new File(targetutl);
//			targetutlfile.delete();
//
//		} else {
//			// 上传到微信的图片路径
//			String url = String.format(WxApiUrl.MEDIA_DL_API, mpaccountService.getAccessToken(mpid), mediaId);
//
//			File targetFile = new File(path);
//			SimpleHttpReq.download(url, targetFile);
//			wxaliyuncsService.uploadFile(filename, path, type);
//
//			// 原始图删除
//			File orgtempfile = new File(path);
//			orgtempfile.delete();
//		}
//		return re;
//	}
//
//	// @Override
//	// public DtoResult downloadAudio(String mpid, String mediaId, String path,
//	// String filename, String type)
//	// throws Exception {
//	// DtoResult re = new DtoResult();
//	//
//	// // 上传到微信的图片路径
//	// String url = String.format(WxApiUrl.MEDIA_DL_API,
//	// mpaccountService.getAccessToken(mpid), mediaId);
//	//
//	// File targetFile = new File(path);
//	// SimpleHttpReq.download(url, targetFile);
//	//
//	// String sourceurl = path;
//	// String targetutl = path.replace(".amr", ".mp3");
//	// targetutl = targetutl.replace(".wav", ".mp3");
//	// String codec = "libmp3lame";
//	// String format = "mp3";
//	// ConvertUtil.convert(sourceurl, targetutl, codec, format);
//	//
//	// String targetutl1 = path + path.replace(".amr", ".wav");
//	// targetutl1 = targetutl1.replace(".wav", ".amr");
//	// ConvertUtil.convert(sourceurl, targetutl1, codec, format);
//	//
//	// wxaliyuncsService.uploadFile(filename, path, url);
//	//
//	// // 原始图删除
//	// File orgtempfile = new File(path);
//	// orgtempfile.delete();
//	//
//	// return re;
//	// }
//


}
