/**
 * 
 */
package com.itinerary.wechat.handler;

import com.itinerary.wechat.mp.commons.WxMsgType;
import com.itinerary.wechat.mp.core.WxDefaultHandler;
import com.itinerary.wechat.mp.vo.OutPutMsg;
import com.itinerary.wechat.mp.vo.ReceiveMsg;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Hasan
 * @Date 2015-8-13 下午4:21:09
 * 
 */
public class ItWxHandler extends WxDefaultHandler {
	private static final Logger log = LoggerFactory.getLogger(ItWxHandler.class);

//	private MPAct mpact;

	public ItWxHandler() {

	}

	/**
	 * 关注
	 */
	@Override
	public OutPutMsg eSub(ReceiveMsg rm) {
		OutPutMsg om = new OutPutMsg(rm);
		om.setMsgType(WxMsgType.text.name());// 推送消息的类型
		om.setContent("欢迎关注拾贝！");
		//TODO 把用户信息存到数据库

		if (log.isInfoEnabled()) {
			log.info("接收到菜单点击消息...");
//			log.info("from={}, to={}, event={}, key={}", rm.getFromUserName(), rm.getToUserName(), rm.getEvent(),
//					rm.getEventKey());
		}
		return om;
	}

	
	
	@Override
	public OutPutMsg eClick(ReceiveMsg rm) {
		OutPutMsg om = new OutPutMsg(rm);
		om.setMsgType(WxMsgType.text.name());
		om.setContent("MENU_CLICK:" + rm.getEventKey());
		if (log.isInfoEnabled()) {
			log.info("接收到菜单点击消息...");
//			log.info("from={}, to={}, event={}, key={}", rm.getFromUserName(), rm.getToUserName(), rm.getEvent(),
//					rm.getEventKey());
		}
		return om;
	}

	/**
	 * 扫描事件
	 */
	@Override
	public OutPutMsg eScan(ReceiveMsg rm) {
		OutPutMsg om = new OutPutMsg(rm);
//		MPAct mpact = mpacts.get(rm.getToUserName());
//		String openid = rm.getFromUserName();
//		String mpid = rm.getToUserName();
//		Integer tenantcode = mpact.getTenantcode();
//		if (log.isInfoEnabled()) {
//			log.info("接收到扫描消息...");
//			log.info("msgid={}, from={}, to={}, event={}, key={}, ticket={}", rm.getMsgId(), rm.getFromUserName(),
//					rm.getToUserName(), rm.getEvent(), rm.getEventKey(), rm.getTicket());
//		}
		
//		DtoResult re = new DtoResult();
//		VoAccount vo = new VoAccount();
//		try {
//			// 查询用户
//			re = wxAccountService.retrieveAccountByOpenid(openid, mpid,tenantcode);
//			vo = (VoAccount) re.getResult();
//			if (vo != null) {// 不是平台用户
//				if (rm.getEventKey() != null && rm.getEventKey().length() > 1) {// 有设备编号（设备+公众号二维码扫描关注）
//					String devicecode = rm.getEventKey();
//					try {
//						re = deviceService.bindManagedDeviceByOpenid(openid, devicecode, tenantcode, vo.getAccountId(), mpid);
//						if (re.getCode().equals("020179")) {// "您已绑定该设备，请勿重复绑定"
//							om.setMsgType(WxMsgType.text.name());// 推送消息的类型
//							om.setContent( "您已经绑定过该设备了，可在我的设备中查看[愉快]");// 推送内容
//							return om;
//						}
//					} catch (Exception e) {
//						log.error("绑定设备出错::" + e);
//					}
//				}
//			}
//		} catch (Exception e) {
//			log.error("查询用户信息出错::" + e);
//		}
		return om;
	}

	@Override
	public OutPutMsg text(ReceiveMsg rm) {
		OutPutMsg om = new OutPutMsg(rm);
		om.setMsgType(rm.getMsgType());
		om.setContent(rm.getContent() + "\n您的消息已经收到[微笑]");
		return om;
	}

	@Override
	public OutPutMsg image(ReceiveMsg rm) {
		OutPutMsg om = new OutPutMsg(rm);
		om.setMsgType(rm.getMsgType());
		om.setMediaId(rm.getMediaId());
//		if (log.isInfoEnabled()) {
//			log.info("接收到微信图像消息...");
//			log.info("msgid={}, from={}, to={}, mediaid={}", rm.getMsgId(), rm.getFromUserName(), rm.getToUserName(),
//					rm.getMediaId());
//		}
		return om;
	}

	@Override
	public OutPutMsg voice(ReceiveMsg rm) {
		OutPutMsg om = new OutPutMsg(rm);
		if (null != rm.getRecognition()) {
			// om.setMsgType(WxMsgType.text.name());
			// om.setContent("您的语音消息已接收.[微笑]\n内容为：" + rm.getRecognition());
		} else {
			// om.setMsgType(rm.getMsgType());
			// om.setMediaId(rm.getMediaId());
		}
//		if (log.isInfoEnabled()) {
//			log.info("接收到音频消息...");
//			log.info("msgid={}, from={}, to={}, mediaid={}, trans={}", rm.getMsgId(), rm.getFromUserName(),
//					rm.getToUserName(), rm.getMediaId(), rm.getRecognition());
//		}
		return om;
	}

	@Override
	public OutPutMsg video(ReceiveMsg rm) {
		OutPutMsg om = new OutPutMsg(rm);
		// om.setMsgType(rm.getMsgType());
		// om.setMediaId(rm.getMediaId());
//		if (log.isInfoEnabled()) {
//			log.info("接收到视频消息...");
//			log.info("msgid={}, from={}, to={}, mediaid={}, thumbmid={}", rm.getMsgId(), rm.getFromUserName(),
//					rm.getToUserName(), rm.getMediaId(), rm.getThumbMediaId());
//		}
		return om;
	}
}
