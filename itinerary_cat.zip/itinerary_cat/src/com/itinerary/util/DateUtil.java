package com.itinerary.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;


public class DateUtil {

	public final static SimpleDateFormat DATE_TIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	public final static SimpleDateFormat SM_DATE_TIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");

	public final static SimpleDateFormat TF_DATE_TIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmss");
	
	public final static SimpleDateFormat MS_DATE_TIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmmssSSS");
	
	public final static SimpleDateFormat DATE_TIME_FORMAT_ID = new SimpleDateFormat("yyMMddHHmmss");

	public final static SimpleDateFormat DATE_TIME_FORMAT2 = new SimpleDateFormat("yyyy-MM");

	public final static SimpleDateFormat DATE_TIME_FORMAT3 = new SimpleDateFormat("HH:mm");

	public final static SimpleDateFormat DATE_TIME_FORMAT4 = new SimpleDateFormat("yyyy-MM-dd");

	public final static SimpleDateFormat DATE_TIME_FORMAT5 = new SimpleDateFormat("yyyy/MM/dd");

	public final static SimpleDateFormat DATE_TIME_FORMAT6 = new SimpleDateFormat("yyyyMM");

	public final static SimpleDateFormat DATE_TIME_FORMAT7 = new SimpleDateFormat("yyyyMMdd");
	
	public final static SimpleDateFormat DATE_TIME_FORMAT8 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

	/**
	 * yyyy-MM-dd HH:mm:ss
	 * 
	 * @param dateStr
	 *            yyyy-MM-dd HH:mm:ss
	 * @return date
	 */
	public static Date parseDateTime(String dateStr) {
		try {
			return DATE_TIME_FORMAT.parse(dateStr);
		} catch (ParseException e) {
		}
		return null;
	}
	

	/**
	 * yyyy-MM-dd HH:mm:ss
	 * 
	 * @param date
	 * @return yyyy-MM-dd HH:mm:ss
	 */
	public static String formatDateTime(Date date) {
		if (date != null) {
			return DATE_TIME_FORMAT.format(date);
		}
		return "";
	}
	/**
	 * yyyyMMddHHmmss
	 * 
	 * @param date
	 * @return yyyyMMddHHmmss
	 */
	public static String formatDateTimeId(Date date) {
		if (date != null) {
			return DATE_TIME_FORMAT_ID.format(date);
		}
		return "";
	}
	
	/**
	 * yyyyMMddHHmmssSSS
	 * 
	 * @param date
	 * @return yyyyMMddHHmmssSSS
	 */
	public static String formatDateTimeMS(Date date) {
		if (date != null) {
			return MS_DATE_TIME_FORMAT.format(date);
		}
		return "";
	}
	
	/**
	 * yyyy-MM-dd'T'HH:mm:ss.SSS转yyyy-MM-dd HH:mm:ss
	 * 
	 * @param date
	 *            yyyy-MM-dd'T'HH:mm:ss.SSS
	 * @return yyyy-MM-dd HH:mm:ss
	 */
	public static String smFormatDateTime(String date) {
		if (date != null) {
			try {
				Date d = SM_DATE_TIME_FORMAT.parse(date);
				return DATE_TIME_FORMAT.format(d);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return "";
	}

	/**
	 * yyyy-MM-dd'T'HH:mm:ss.SSS
	 * 
	 * @param date
	 * @return yyyy-MM-dd'T'HH:mm:ss.SSS
	 */
	public static String smFormatDateTime(Date date) {
		if (date != null) {
			return SM_DATE_TIME_FORMAT.format(date);
		}
		return "";
	}

	/**
	 * yyyy-MM-dd HH:mm:ss转yyyy-MM-dd'T'HH:mm:ss.SSS
	 * 
	 * @param yyyy
	 *            -MM-dd HH:mm:ss
	 * @return yyyy-MM-dd'T'HH:mm:ss.SSS
	 */
	public static String FormatDateTime(String time) {
		Date date = null;
		SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd  HH:mm:ss");
		try {
			date = DATE_TIME_FORMAT.parse(time);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		if (date != null) {
			return SM_DATE_TIME_FORMAT.format(date);
		}
		return "";
	}

	/**
	 * yyyyMMddHHmmss转yyyy-MM-dd'T'HH:mm:ss.SSS
	 * 
	 * @param time
	 *            yyyyMMddHHmmss
	 * @return yyyy-MM-dd'T'HH:mm:ss.SSS
	 */
	public static String TfFormatDateTime(String time) {
		Date date = null;
		try {
			date = TF_DATE_TIME_FORMAT.parse(time);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		if (date != null) {
			return SM_DATE_TIME_FORMAT.format(date);
		}
		return "";
	}

	/**
	 * yyyy-MM
	 * 
	 * @param dateStr
	 * @return
	 */
	public static Date parseDateTime2(String dateStr) {
		try {
			return DATE_TIME_FORMAT2.parse(dateStr);
		} catch (ParseException e) {
		}
		return null;
	}

	/**
	 * yyyy-MM
	 * 
	 * @param dateStr
	 * @return
	 */
	public static String formatDateTime2(Date date) {
		if (date != null) {
			return DATE_TIME_FORMAT2.format(date);
		}
		return "";
	}

	/**
	 * 以指定格式返回,如果不指定则以yyyy-MM-dd HH:mm:ss
	 * 
	 * @param date
	 * @param formatStr
	 *            格式
	 * @return
	 */
	public static String formatDateTime(Date date, String formatStr) {
		if (date != null) {
			if (!StringUtils.isBlank(formatStr)) {
				SimpleDateFormat format = new SimpleDateFormat(formatStr);
				return format.format(date);
			} else {
				return DATE_TIME_FORMAT.format(date);
			}
		}
		return "";
	}

	/**
	 * HH:mm
	 * 
	 * @param date
	 * @return
	 */
	public static String formatDateTime3(Date date) {
		if (date != null) {
			return DATE_TIME_FORMAT3.format(date);
		}
		return "";
	}

	/**
	 * yyyy-MM-dd
	 * 
	 * @param date
	 * @return yyyy-MM-dd
	 */
	public static String formatDateTime4(Date date) {
		if (date != null) {
			return DATE_TIME_FORMAT4.format(date);
		}
		return "";
	}

	/**
	 * yyyy-MM-dd
	 * 
	 * @param date
	 * @return yyyy-MM-dd
	 */
	public static Date parseDateTime4(String dateStr) {
		try {
			return DATE_TIME_FORMAT4.parse(dateStr);
		} catch (ParseException e) {
		}
		return null;
	}

	/**
	 * yyyy/MM/dd
	 * 
	 * @param date
	 * @return
	 */
	public static String formatDateTime5(Date date) {
		if (date != null) {
			return DATE_TIME_FORMAT5.format(date);
		}
		return "";
	}

	/**
	 * yyyy/MM/dd
	 * 
	 * @param date
	 * @return
	 */
	public static Date parseDateTime5(String dateStr) {
		try {
			return DATE_TIME_FORMAT5.parse(dateStr);
		} catch (ParseException e) {
		}
		return null;
	}

	/**
	 * yyyyMM
	 * 
	 * @param date
	 * @return
	 */
	public static String formatDateTime6(Date date) {
		if (date != null) {
			return DATE_TIME_FORMAT6.format(date);
		}
		return "";
	}

	/**
	 * yyyyMM
	 * 
	 * @param dateStr
	 * @return
	 */
	public static Date parseDateTime6(String dateStr) {
		try {
			return DATE_TIME_FORMAT6.parse(dateStr);
		} catch (ParseException e) {
		}
		return null;
	}

	/**
	 * yyyyMMdd
	 * 
	 * @param date
	 * @return
	 */
	public static String formatDateTime7(Date date) {
		if (date != null) {
			return DATE_TIME_FORMAT7.format(date);
		}
		return "";
	}
	
	/**
	 * yyyy-MM-dd HH:mm:ss.sss
	 * 
	 * @param date
	 * @return yyyy-MM-dd HH:mm:ss
	 */
	public static String formatDateTime8(Date date) {
		if (date != null) {
			return DATE_TIME_FORMAT8.format(date);
		}
		return "";
	}

	/**
	 * 得到本月的第一天
	 * 
	 * @return
	 */
	public static String getMonthFirstDay(Calendar calendar) {
		calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));

		return formatDateTime4(calendar.getTime());
	}

	/**
	 * 得到本月的最后一天
	 * 
	 * @return
	 */
	public static String getMonthLastDay(Calendar calendar) {
		calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
		return formatDateTime4(calendar.getTime());
	}

	/**
	 * 判断传入时间是否在当前时间加减多少秒的区间内
	 * 
	 * @param date
	 *            格式必须是yyyy-MM-dd HH:mm:ss
	 * @param seconds
	 *            正负皆可,正表示当前时间往前推，负表示当前时间往后推
	 * @return
	 */
	public static boolean isBetween(String date, int seconds) {
		if (date != null) {
			try {
				Date time = DATE_TIME_FORMAT.parse(date);
				long begin, end;
				if (seconds > 0) {
					end = System.currentTimeMillis();
					begin = end - seconds * 1000;
				} else {
					begin = System.currentTimeMillis();
					end = begin - seconds * 1000;
				}
				return time.getTime() >= begin && time.getTime() <= end;
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
	}

	/**
	 * 获取当前星期几
	 * 
	 * @param dt
	 * @return
	 */
	public static String getWeekOfDate(Date dt) {
		String[] weekDays = { "星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六" };
		Calendar cal = Calendar.getInstance();
		cal.setTime(dt);
		int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
		if (w < 0)
			w = 0;
		return weekDays[w];
	}

	/**
	 * 获取i天后的工作日(不排除法定节假日)
	 * 
	 * @param 如今天星期4
	 *            ，2或3或4天后就是星期一
	 * @return yyyy-MM-dd
	 */
	public static String nextBusinessDay(List<String> dateList, int i) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date dt = new Date();
		if (i > 0) {
			for (int j = 0; j < i; j++) {
				dt = new Date(dt.getTime() + 86400000L);
				if (dateList.contains(sdf.format(dt))) {
					j--;
				}
			}
		} else if (i < 0) {
			for (int j = 0; j > i; j--) {
				dt = new Date(dt.getTime() - 86400000L);
				if (dateList.contains(sdf.format(dt))) {
					j++;
				}
			}
		}
		return sdf.format(dt);
	}

	/**
	 * 获取当前星期几
	 * 
	 * @param str
	 * @return
	 */
	public static String getWeekOfDate(String str) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日");
		Date date = new Date();
		try {
			date = sdf.parse(str);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String[] weekDays = { "星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六" };
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
		if (w < 0)
			w = 0;
		return weekDays[w];
	}

	/**
	 * 获取当前星期几
	 * 
	 * @param str
	 *            yyyy-MM-dd
	 * @return
	 */
	public static String getWeekOfDate2(String str) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		try {
			date = sdf.parse(str);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		String[] weekDays = { "星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六" };
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
		if (w < 0)
			w = 0;
		return weekDays[w];
	}

	/**
	 * 获取i天后的日期
	 * 
	 * @return yyyy-MM-dd
	 */
	public static String getFutureDate(int i) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date dt = new Date();
		dt = new Date(dt.getTime() + i * 86400000L);
		dt.setTime(dt.getTime());
		return sdf.format(dt);
	}

	/**
	 * 获取i天后的日期
	 * 
	 * @return yyyyMMdd
	 */
	public static String getSgFutureDate(int i) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Date dt = new Date();
		dt = new Date(dt.getTime() + i * 86400000L);
		dt.setTime(dt.getTime());
		return sdf.format(dt);
	}

	/**
	 * 获取i天后的日期
	 * 
	 * @return yyyy-MM-dd'T'HH:mm:ss.SSS
	 */
	public static String getFutureDate(String date, int i) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		Date dt = null;
		try {
			dt = sdf.parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		dt = new Date(dt.getTime() + i * 86400000L);
		dt.setTime(dt.getTime());
		return sdf.format(dt);
	}

	public static void main(String args[]) {
		List<String> list = new ArrayList<String>();
		list.add("2016-03-13");
		list.add("2016-03-12");
		list.add("2016-03-11");
		list.add("2016-03-07");
		list.add("2016-03-06");
		list.add("2016-03-05");
		list.add("2016-03-04");
		list.add("2016-03-03");
		list.add("2016-03-01");
		String s = nextBusinessDay(list, -1);
		System.out.println(s);
	}

	/**
	 * yyyyMMdd转yyyy-MM-dd
	 * 
	 * @throws ParseException
	 */
	public static String getFutureDate(String time) {
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyyMMdd");
		Date date = null;
		try {
			date = sdf1.parse(time);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
		return sdf2.format(date);
	}

	/**
	 * yyyy-MM-dd HH:mm:ss.S转yyyy-MM-dd'T'HH:mm:ss.SSS
	 * 
	 * @throws ParseException
	 */
	public static String getSmT(String time) throws ParseException {
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		Date date = sdf1.parse(time);
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		return sdf2.format(date);
	}

	/**
	 * yyyy-MM-dd'T'HH:mm:ss.SSS获取时间毫秒数
	 * 
	 * @throws ParseException
	 */
	public static long getDateLong(String time) throws ParseException {
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		return sdf2.parse(time).getTime();
	}

	/**
	 * 去除法定节假日后，i个工作日后的日期
	 * 
	 * @param dateList
	 * @param applyDateTime
	 * @param i
	 * @return yyyy-MM-dd
	 */
	public static String nextBusinessDay(List<String> dateList, String applyDateTime, int i) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date dt = parseDateTime(applyDateTime);
		if (i > 0) {
			for (int j = 0; j < i; j++) {
				dt = new Date(dt.getTime() + 86400000L);
				if (dateList.contains(sdf.format(dt))) {
					j--;
				}
			}
		} else if (i < 0) {
			for (int j = 0; j > i; j--) {
				dt = new Date(dt.getTime() - 86400000L);
				if (dateList.contains(sdf.format(dt))) {
					j++;
				}
			}
		}
		return sdf.format(dt);
	}

	
	public static String getFriendlytime(Timestamp date) {
		long delta = (new Date().getTime()-date.getTime())/1000; 
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");   
		if (delta <= 0 || delta / (60 * 60 * 24 * 365) > 0
				|| delta / (60 * 60 * 24 * 30) > 0
				|| delta / (60 * 60 * 24 * 7) > 0)
			return sdf.format(date);
		// if(delta/(60*60*24*365) > 0) return delta/(60*60*24*365) +"年前";
		// if(delta/(60*60*24*30) > 0) return delta/(60*60*24*30) +"个月前";
		// if(delta/(60*60*24*7) > 0)return delta/(60*60*24*7) +"周前";
		if (delta / (60 * 60 * 24) > 0)
			return delta / (60 * 60 * 24) + "天前";
		if (delta / (60 * 60) > 0)
			return delta / (60 * 60) + "小时前";
		if (delta / (60) > 0)
			return delta / (60) + "分钟前";
		return "刚刚";
	}
	
}
