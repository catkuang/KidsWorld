package com.itinerary.util;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

public class PropertiesUtil {
	public static FileInputStream file;
	public static Properties pros = null;
	public static String url = "";

	public static Map<String, String> getPropertiesValues(HttpServletRequest request, String url) {
		try {
			if (file == null || PropertiesUtil.url != url) {
				PropertiesUtil.url = url;
				String filePath = request.getSession().getServletContext().getRealPath(url);
				file = new FileInputStream(filePath);
				pros = new Properties();
				pros.load(new BufferedInputStream(file));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Map<String, String> map = new HashMap<String, String>((Map) pros);
		return map;
	}

}
