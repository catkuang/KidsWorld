package com.itinerary.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

/**
 * 上传文件 创建人：FH 创建时间：2014年12月23日
 * 
 * @version
 */
public class FileUpload {
	/**
	 * 多文件上传
	 * 
	 * @param request
	 * @param path
	 *            存储路径
	 * @throws IllegalStateException
	 * @throws IOException
	 */
	public static void upload(HttpServletRequest request, String path,
			boolean issuo) throws IllegalStateException, IOException {
		FileUtil.createDir(path);
		// 创建一个通用的多部分解析器
		CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver(
				request.getSession().getServletContext());
		// 判断 request 是否有文件上传,即多部分请求
		if (multipartResolver.isMultipart(request)) {
			// 转换成多部分request
			MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;
			// 取得request中的所有文件名
			Iterator<String> iter = multiRequest.getFileNames();
			int size = multiRequest.getFileMap().size();
			while (iter.hasNext()) {
				// 取得上传文件
				MultipartFile file = multiRequest.getFile(iter.next());
				if (file != null) {
					// 取得当前上传文件的文件名称
					String myFileName = file.getOriginalFilename();
					// 如果名称不为“”,说明该文件存在，否则说明该文件不存在
					if (myFileName.trim() != "") {
						// 重命名上传后的文件名
						Long time = System.currentTimeMillis();
						String fileName = time + file.getOriginalFilename();
						// 定义上传路径
						String imgpath = path + File.separator + fileName;
						File localFile = new File(imgpath);
						file.transferTo(localFile);
						// 原图已上传完毕
						if (issuo) {
							String imgpath2 = path + File.separator + "s"
									+ File.separator + fileName;
							File sfile = new File(imgpath2);
							String wh = ImageUtil.resize(imgpath, imgpath2,
									180, 1F);
							int w = Integer.parseInt(wh.split(",")[0]);
							int h = Integer.parseInt(wh.split(",")[1]);
							int x = 0;
							int y = 0;
							if (size > 1) {
								if (w > h) {
									x = (w - h) / 2;
								} else if (h > w) {
									y = (h - w) / 2;
								}
								w = 180;
								h = 180;
							} else {
								if (w > h) {
									w = w * 180 / h;
									h = 180;
								} else {
									h = h * 180 / w;
									w = 180;
								}
								x = 0;
								y = 0;
							}
							ImageUtil.cut(sfile, sfile, x, y, w, h);
						}
					}
				}
			}
		}
	}

	/**
	 * @param file
	 *            //文件对象
	 * @param filePath
	 *            //上传路径
	 * @param fileName
	 *            //文件名
	 * @return 文件名
	 */
	public static String fileUp(MultipartFile file, String filePath,
			String fileName) {
		String extName = ""; // 扩展名格式：
		try {
			if (file.getOriginalFilename().lastIndexOf(".") >= 0) {
				extName = file.getOriginalFilename().substring(
						file.getOriginalFilename().lastIndexOf("."));
			}
			copyFile(file.getInputStream(), filePath, fileName + extName)
					.replaceAll("-", "");
		} catch (IOException e) {

		}
		return fileName + extName;
	}

	/**
	 * 写文件到当前目录的upload目录中
	 * 
	 * @param in
	 * @param fileName
	 * @throws IOException
	 */
	private static String copyFile(InputStream in, String dir, String realName)
			throws IOException {
		File file = new File(dir, realName);
		if (!file.exists()) {
			if (!file.getParentFile().exists()) {
				file.getParentFile().mkdirs();
			}
			file.createNewFile();
		}
		FileUtils.copyInputStreamToFile(in, file);
		return realName;
	}
}
