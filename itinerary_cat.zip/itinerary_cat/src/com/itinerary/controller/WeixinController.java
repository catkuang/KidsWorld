package com.itinerary.controller;

import com.alibaba.fastjson.JSONObject;
//import com.cnsebe.weixin.core.service.redis.RedisClientTemplate;
//import com.itinerary.wechat.core.weixin.util.HttpConnectUtil;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("weixinController")
public class WeixinController {
	
//	private static final Logger logger = Logger
//			.getLogger(WeixinController.class);
//
////	@Autowired
////	private RedisClientTemplate redisClientTemplate;
//
//	@Value("${mp.weixin.appid}")
//	protected String mpWeixinAppid;
//	@Value("${mp.weixin.secret}")
//	protected String mpWeixinSecret;
//	@Value("${mp.smooth.time}")
//	protected String mpSmoothTime;
//
//
//
//	/**
//	 *@Author:luoshuifang
//	 *@Description:获取普通类型access_token 从redis获取
//	 *@Date:14:11 2016/11/11
//	**/
//
//	public String getTokenFromWeixinRedis() {
//		String accessToken = null;
//
////		if(redisClientTemplate.exists(mpWeixinAppid+"wx_access_token")){
////			System.out.println("from redis key:"+mpWeixinAppid+"wx_access_token");
////			accessToken = redisClientTemplate.get(mpWeixinAppid+"wx_access_token");
////			return (String) accessToken;
////		}
//
//		logger.debug("Start to get token from weixin server.");
//		accessToken = getTokenFromWeixinServer();
//		logger.debug("Get access token result:" + accessToken);
//		return (String) accessToken;
//	}
//	
//	/**
//	 * 获取普通类型access_token 从数据库获取
//	 * 
//	 * @return
//	 *//*
//	public String getTokenFromWeixinDB() {
//
//		// 查询access token数据
//		Map<String, Object> result = weixinDAO.queryWeixinAccessToken();
//
//		Object accessToken = null;
//		if (result != null && result.size() > 0) {
//			accessToken = result.get("access_token");
//		}
//
//		// 当未超过access token失效时间，直接返回从数据库读取的access token值
//		if (accessToken != null) {
//			int expiresIn = (Integer) result.get("expires_in");
////			Date lastUpdate = (Date) result.get("update_time");
//
////			//数据库update_time有date改成int型，下面做转化 --by chandler
//			int lastUpdate = (Integer) result.get("update_time");
//
//
//			int smoothTime = 0;
//			try{
//				smoothTime = Integer.parseInt(mpSmoothTime);
//			}catch(Exception e) {
//				logger.error(e);
//			}
//			
//			//数据库的时间是10位，精确到秒，所以系统时间/1000
//			if (System.currentTimeMillis()/1000 - lastUpdate < (expiresIn - smoothTime)) {
//				return (String) accessToken;
//			}
//			
//			logger.debug("token in db is expired.");
//		}
//
//		logger.debug("Start to get token from weixin server.");
//		accessToken = getTokenFromWeixinServer();
//		logger.debug("Get access token result:" + accessToken);
//
//		return (String) accessToken;
//	}
//
//	*/
//
//
//
//	 /**
//	 * 获取Openid
//	 * 
//	 * @param code
//	 * @return
//	 */
//	public String getOpenID(String code) {
//		String openIdUrl = "https://api.weixin.qq.com/sns/oauth2/access_token?appid="
//				+ mpWeixinAppid
//				+ "&secret="
//				+ mpWeixinSecret
//				+ "&code="
//				+ code
//				+ "&grant_type=authorization_code";
//		String str = HttpConnectUtil.httpsGetConnect(openIdUrl);
//
//		logger.debug("Get openid result:" + str);
//
//		JSONObject jsonObj = JSONObject.parseObject(str);
//
//		return jsonObj.getString("openid");
//	}
//
//	/**
//	 * 从微信服务器获取token
//	 * 
//	 * @return
//	 */
//	public String getTokenFromWeixinServer() {
//		// access token失效时从微信服务器重新获取
//		String accessTokenStr = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid="
//				+ mpWeixinAppid + "&secret=" + mpWeixinSecret;
//
//		String str = HttpConnectUtil.httpsGetConnect(accessTokenStr);
//		String accessToken = null;
//		if (str != null) {
//			JSONObject jsonObj = JSONObject.parseObject(str);
//			// 接口访问凭证
//			accessToken = jsonObj.getString("access_token");
//			// 凭证有效期
//			int expiresIn = jsonObj.getIntValue("expires_in");
//			// 将数据保存到数据库
//			logger.debug("Update weixin Token to DB: expiresIn=" + expiresIn
//					+ "accessToken=" + accessToken);
//
//			int smoothTime = 0;
//			try{
//				smoothTime = Integer.parseInt(mpSmoothTime);
//			}catch(Exception e) {
//				logger.error(e);
//			}
//
//			redisClientTemplate.setex(mpWeixinAppid+"wx_access_token",expiresIn - smoothTime ,accessToken);
//		}
//		return accessToken;
//	}
//
//
//
////	/**
////	 * 获取用户信息json
////	 *
////	 * @param openid
////	 * @return
////	 */
////	public String getUserInfoJson(String openid) {
////
////		String accessToken = getTokenFromWeixinRedis();
////		String userInfoUrl = "https://api.weixin.qq.com/cgi-bin/user/info?access_token="
////				+ accessToken + "&openid=" + openid;
////		String str = HttpConnectUtil.httpsGetConnect(userInfoUrl);
////		return str;
////	}
//
//	/**
//	 * 更新微信用户信息
//	 * 
//	 * @param openid
//	 * @return
//	 */
//	public synchronized void updateUserInfo(String openid) {
//
//		/*Map<String, Object> userinfo = weixinDAO.queryWeixinUserInfo(openid);
//		if (userinfo == null || userinfo.size() == 0) {
//			
//			// 获取用户信息
//			String userInfoJson = getUserInfoJson(openid);
//
//			JSONObject jsonObj = JSONObject.parseObject(userInfoJson);
//
//			String nickname = jsonObj.getString("nickname");
//			
//			//过滤表情符号
////			String filterNickname = EmojiFilter.filterEmoji(nickname);
////			nickname = filterNickname.trim().equals("") ? "昵称":filterNickname;
//			
////			logger.debug("emoji start -> ."+nickname+".");
////			if(nickname != null || !"".equals(nickname)) {
////				Pattern emoji = Pattern.compile(
////						 "[\ud83c\udc00-\ud83c\udfff]|[\ud83d\udc00-\ud83d\udfff]|[\u2600-\u27ff]",
////				         Pattern.UNICODE_CASE | Pattern.CASE_INSENSITIVE );
////				
////				nickname = nickname.replaceAll(emoji.pattern(), "");
////			}
////			logger.debug("emoji after -> ."+nickname+".");
//			
//			int sex = jsonObj.getIntValue("sex");
//			String headimgurl = jsonObj.getString("headimgurl");
//
//			logger.debug("Update userInfo:(" + openid + "," + nickname + ","
//					+ sex + "," + headimgurl + ")");
//
//			int result = weixinDAO.addWeixinUserInfo(openid, nickname, sex,
//					headimgurl);
//			logger.info("DB Operate result:" + result);
//		}*/
//	}
//

}
