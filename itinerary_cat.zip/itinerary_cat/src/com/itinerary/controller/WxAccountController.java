package com.itinerary.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.itinerary.dto.Result;
import com.itinerary.entity.WxAccount;
import com.itinerary.service.WxAccountService;

@RequestMapping("/wxaccount")
@Controller
public class WxAccountController {

	@Resource(name = "wxaccountService")
	private WxAccountService wxaccountService;

	@RequestMapping(value = "/getWxAccountByOpenid", method = RequestMethod.GET)
	@ResponseBody
	public Result getWxAccountByOpenid(@RequestParam(value = "openid", required = true) String openid) {
		try {
			WxAccount wxaccount = wxaccountService.queryWxAccountByOpenid(openid);
			return new Result(wxaccount, "0");
		} catch (Exception e) {
			e.printStackTrace();
			return new Result("系统错误", "-9");
		}
	}
	
	@RequestMapping(value = "/getAllWxAccount", method = RequestMethod.GET)
	@ResponseBody
	public Result getAllWxAccount() {
		try {
			List<WxAccount> wxaccountJsonList = wxaccountService.queryAllWxAccount();
			return new Result(wxaccountJsonList, "0");
		} catch (Exception e) {
			e.printStackTrace();
			return new Result("系统错误", "-9");
		}
	}
	
	
	

}
