package com.itinerary.controller;

import com.alibaba.fastjson.JSON;
//import com.cnsebe.tools.api.bean.base.ResultBase;
//import com.cnsebe.tools.api.bean.trademark.WxaccountInfo;
//import com.cnsebe.tools.api.trademarkSearch.WxaccountService;
//import com.itinerary.wechat.mp.core.SignAuthenticate;
//import com.cnsebe.weixin.core.weixin.util.HttpConnectUtil;
import com.itinerary.wechat.mp.vo.Follower;
//import com.exodus.iprp.user.DTO.MemberDTO;
//import com.exodus.iprp.user.IServive.MemberService;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;

@Controller()
@RequestMapping(value = "/wechat")
public class WechatController extends WeixinController {

    private Log logger = LogFactory.getLog(WechatController.class);

//    @Autowired
//    private WxaccountService wxaccountService;
//
//    @Autowired
//    private MemberService memberService;

    /**
     * 微信api专用（微信访问入口）
     *
     * @param req
     * @return
     */
    @ResponseBody
    @RequestMapping(value = "/core", produces = {"text/plain;charset=UTF-8"})
    public String wxCore(HttpServletRequest req, HttpServletResponse response) {
        String reply = "";
        try {
            String method = req.getMethod();
            //GET请求处理
            if ("GET".equals(method)) {
                reply = check(req);
                return reply;
            }
            //POST请求处理
            reply = handler(req);
        } catch (Exception e) {
            logger.error(e.getLocalizedMessage(), e);
        }
        return reply;
    }


    public String check(HttpServletRequest request) throws ServletException, IOException {
        String signature = request.getParameter("signature");
        // 时间戳
        String timestamp = request.getParameter("timestamp");
        // 随机数
        String nonce = request.getParameter("nonce");
        // 随机字符串
        String echostr = request.getParameter("echostr");
        // 通过检验signature对请求进行校验，若校验成功则原样返回echostr，表示接入成功，否则接入失败
        
        
//        if (SignAuthenticate.checkSignature(signature, timestamp, nonce)) {
//            return echostr;
//        }
        return "";
    }

    public String handler(HttpServletRequest req) throws Exception {
        String reply = "";
//		InputStream wxInMsg = req.getInputStream();
//		this.rm = convert2VO(this.wxInMsg);
//		// 处理消息
//		String msg_type = this.rm.getMsgType();
//		if ("event".equals(msg_type)) {
//			this.om = handlerEvent();
//		} else {
//			this.om = handlerMsg();
//		}
//		// 输出消息
//		if (null != this.om) {
//			//客服
//			reply = this.convert2XML(this.om);
//		}


        return reply;
    }


    /**
     * 网页访问入口
     */
    @ResponseBody
    @RequestMapping(value = "/pageentry", method = RequestMethod.GET)
    public ModelAndView pageentry(@RequestParam("menu") String menu, @RequestParam("code") String code,
                                  @RequestParam("state") String state, HttpSession session) {
        ModelAndView view = null;
        // 网页授权
        logger.info("weixinmenu.code=" + code + " state=" + state + " menu=" + menu);
        try {
//            String openid = getOpenID(code);
//            //根据openid查询是否绑定过 获取用户信息
//            WxaccountInfo wxaccountInfo = wxaccountService.selectByOpenid(openid);
//            session.setAttribute("wxaccount_openid", openid);
//
//            if(wxaccountInfo != null ){
//                if (wxaccountInfo.getUserid() != null && wxaccountInfo.getUserid() == 0) {
//                    session.setAttribute("wxaccount_userid", null);
//                }else{
//                    session.setAttribute("wxaccount_userid", wxaccountInfo.getUserid());
//                }
//
//                //根据userid查询用户信息
//                if (wxaccountInfo.getUserid() != null && wxaccountInfo.getUserid().intValue() > 0) {
//                    try{
//                        MemberDTO dto = memberService.findOne(wxaccountInfo.getUserid());
//                        session.setAttribute("wxaccount_phone", dto.phone);
//                        session.setAttribute("wxaccount_userName", dto.truename);
//                    }catch(Exception e){
//                        logger.error(e);
//                    }
//                }
//            }
//
//            if (menu != null && !menu.isEmpty()) {
//                if (menu.equals("queryTmMark")) {
//                    view = new ModelAndView("redirect:/page/templates/brandRating/brandRatingIndex.html");// 商品查询页
//                } else if (menu.equals("bindwxaccount")) {
//                    view = new ModelAndView("redirect:/page/templates/userBinding/userBindingIndex.html");// 绑定
//                } else if (menu.equals("queryTrademarkSchedule")) {
//                    view = new ModelAndView("redirect:/page/templates/progressQuery/progressQueryIndex.html");// 商品查询页
//                }else if (menu.equals("brandName")) {
//                    view = new ModelAndView("redirect:/page/templates/brandName/brandNameIndex.html");// 好名推荐
//                }
//            }
            logger.info("pageentry::");
        } catch (Exception e) {
            logger.error("weixinmenu::" + e);
        }
        return view;
    }

//
//    /**
//     * 微信用户绑定，微信openid和用户account(手机号唯一确定）做关联，如果不存在要添加  存在就绑定（修改userid）
//     *
//     * @param phone
//     * @param password
//     * @param session
//     * @return @VoAccount
//     */
//
//    @ResponseBody
//    @RequestMapping(value = "/bindUserid2Wxaccount", method = RequestMethod.POST)
//    public ResultBase<Object> bindUserid2Wxaccount(@RequestParam("phone") String phone, @RequestParam("password") String password, HttpSession session) {
//        ResultBase<Object> re = new ResultBase<Object>();
//        try {
//            Object wxaccount_openid = session.getAttribute("wxaccount_openid");
////            String openid = "o0wbfv19ocaHYg96Swf6vudOTOvc";
//            if (wxaccount_openid == null) {
//                re.setData("页面已失效，请重新打开");
//                re.setErrorCode("102");
//                return re;
//            }
//            //根据手机号和密码获取用户信息
//            MemberDTO dto = new MemberDTO();
//            dto.phone = phone;
//            dto.password = password;
////            dto.setPassword(password);
////            dto = loginDubboService.checkLogin(dto);
//            try {
//                dto = memberService.login(dto);
//            } catch (Exception e) {
//                re.setData("账户名或密码错误");
//                re.setErrorCode("101");
//                return re;
//            }
//
//            String openid = wxaccount_openid.toString();
//            if (dto != null && dto.member_id != null) {
//                //根据openid查
//                WxaccountInfo wxaccountInfo = wxaccountService.selectByOpenid(openid);
//                if (wxaccountInfo != null && wxaccountInfo.getOpenid() != null && wxaccountInfo.getUserid().intValue() == dto.member_id.intValue()) {
//                    re.setData("已经绑定过该账户无需再次绑定");
//                    re.setErrorCode("102");
//                    return re;
//                }
//                if (wxaccountInfo != null && wxaccountInfo.getOpenid() != null) {//已存在直接绑定
//                    wxaccountInfo.setUserid(dto.member_id);
//                    wxaccountService.updateByPrimaryKeySelective(wxaccountInfo);
//                } else {//不存在 就添加微信用户
//                    wxaccountInfo = new WxaccountInfo();
//                    wxaccountInfo.setUserid(dto.member_id);
//                    Follower fllower = getFollower(openid, "zh_CN");
//                    if (fllower != null) {
//                        wxaccountInfo.setOpenid(openid);
//                        wxaccountInfo.setCity(fllower.getCity());
//                        wxaccountInfo.setLanguage(fllower.getLanguage());
//                        wxaccountInfo.setCountry(fllower.getCountry());
//                        wxaccountInfo.setHeadimgurl(fllower.getHeadImgUrl());
//                        wxaccountInfo.setNickname(fllower.getNickName());
//                        wxaccountInfo.setProvince(fllower.getProvince());
//                        wxaccountInfo.setUnionid(fllower.getUnionid());
//                        wxaccountInfo.setSex(fllower.getSex());
//                        wxaccountInfo.setSubscribe(fllower.getSubscribe());
//                        wxaccountInfo.setRemark(fllower.getRemark());
//                        wxaccountInfo.setGroupid(fllower.getGroupid());
//                        wxaccountInfo.setSubscribeTime(new Date(fllower.getSubscribeTime() * 1000));
//                        wxaccountService.insertSelective(wxaccountInfo);
//                    } else {
//                        re.setData("获取微信用户信息失败");
//                        re.setErrorCode("102");
//                        return re;
//                    }
//                }
//                re.setData("绑定成功");
//                re.setErrorCode("0");
//                session.setAttribute("wxaccount_userid", dto.member_id);
//            } else {
//                re.setData("用户名或密码错误");
//                re.setErrorCode("101");
//            }
//        } catch (Exception e) {
//            re.setData("服务器出现异常");
//            re.setErrorCode("EEEEE");
//            logger.error("bindOpenid2Account::" + e);
//        }
//        return re;
//    }
//
//    /**
//     * 获取关注者的信息
//     *
//     * @param openId 用户ID
//     * @param lang   使用语言
//     * @return 关注者的基本信息
//     */
//    public Follower getFollower(String openId, String lang) {
//        String userInfoUrl = "https://api.weixin.qq.com/cgi-bin/user/info?access_token="
//                + getTokenFromWeixinRedis() + "&openid=" + openId + "&lang=" + lang;
//        String result = "";
//        try {
//            result = HttpConnectUtil.httpsGetConnect(userInfoUrl);
//        } catch (Exception e) {
//            logger.error("获取用户信息时出现异常!!!");
//            logger.error(e.getLocalizedMessage(), e);
//        }
////            if (result.isEmpty() || result.indexOf("errcode") > -1) {
////                throw new WxRespException(result);
////            }
//        if (result.isEmpty() || result.indexOf("errcode") > -1) {
//            return null;
//        }
//        Follower follower = JSON.parseObject(result, Follower.class);
//        return follower;
//    }
//
//
//    /**
//     * 微信用户解绑，微信openid和用户account(手机号唯一确定）取消关联
//     *
//     * @param session
//     * @return @VoAccount
//     */
//
//    @ResponseBody
//    @RequestMapping(value = "/unbindUserid2Wxaccount", method = RequestMethod.POST)
//    public ResultBase<Object> unbindUserid2Wxaccount(HttpSession session) {
//        ResultBase<Object> re = new ResultBase<Object>();
//        try {
//            Object openid = session.getAttribute("wxaccount_openid");
////            String openid = "o0wbfv19ocaHYg96Swf6vudOTOvc";
//            if (openid == null) {
//                re.setErrorCode("104");
//                re.setData("未绑定账户无需解绑");
//                return re;
//            }
//
//            WxaccountInfo wxaccountInfo = wxaccountService.selectByOpenid(openid.toString());
//            if (wxaccountInfo.getUserid() == null || wxaccountInfo.getUserid().intValue() == 0) {
//                re.setErrorCode("104");
//                re.setData("未绑定账户无需解绑");
//                return re;
//            }
//
//            if (wxaccountInfo != null && wxaccountInfo.getUserid() != null) {//已存在直接绑定
//                wxaccountInfo.setUserid(0);
//                wxaccountService.updateByPrimaryKeySelective(wxaccountInfo);
//                re.setErrorCode("0");
//                re.setData("解绑成功");
//            }
//        } catch (Exception e) {
//            re.setErrorCode("EEEEE");
//            re.setData("服务器出现异常");
//            logger.error("unbindUserid2Wxaccount::" + e);
//        }
//        return re;
//    }


    //	/**
//	 * 获取JSAPI签名
//	 *
//	 * @param url
//	 * @param session
//	 * @return
//	 */
//	@ResponseBody
//	@RequestMapping(value = HbConstant.V_URL_ROOT_WEIXIN + "/getJsAPISignByUrl", method = RequestMethod.GET)
//	public DtoResult getJsAPISignByUrl(@RequestParam("url") String url, HttpSession session) {
//		DtoResult re = new DtoResult();
//		try {
//			String mpid = session.getAttribute(HbConstant.S_SESSION_MPID).toString();
//			re = wexinService.getJsAPISignByUrl(mpid, url);
//			log.info("getJsAPISignByUrl.url=" + url);
//		} catch (Exception e) {
//			re.setCode(HbConstant.RESULT_CODE_FAILURE);
//			re.setResult(e);
//			log.error("getJsAPISignByUrl::" + e);
//		}
//		return re;
//	}

}
