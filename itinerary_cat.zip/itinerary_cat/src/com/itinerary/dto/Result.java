package com.itinerary.dto;

public class Result {
	private Object data;
	
	private String sign;

	private String msec;

	private String code;
	
	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getMsec() {
		return msec;
	}

	public void setMsec(String msec) {
		this.msec = msec;
	}
	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Result() {
		this.msec = String.valueOf(System.currentTimeMillis());
	}

	public Result(Object data, String code) {
		super();
		this.data = data;
		this.msec = String.valueOf(System.currentTimeMillis());
		this.code = code;
	}
	
	public Result(Object data, String code,String sign) {
		super();
		this.data = data;
		this.msec = String.valueOf(System.currentTimeMillis());
		this.code = code;
		this.sign = sign;
	}
	
	
}
