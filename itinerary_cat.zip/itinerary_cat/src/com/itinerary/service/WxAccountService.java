package com.itinerary.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.itinerary.dao.DaoSupport;
import com.itinerary.entity.WxAccount;

@Service("wxaccountService")
public class WxAccountService {

	@Resource(name = "daoSupport")
	private DaoSupport dao;

	public WxAccount queryWxAccountByOpenid(String openid) throws Exception {
		return (WxAccount) dao.findForObject("WxAccountMapper.queryWxAccountByOpenid", openid);
	}

	@SuppressWarnings("unchecked")
	public List<WxAccount> queryAllWxAccount() throws Exception {
		return (List<WxAccount>) dao.findForList("WxAccountMapper.queryAllWxAccount", null);
	}

}
