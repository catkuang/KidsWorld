DROP TABLE IF EXISTS `wxaccount`;
CREATE TABLE `wxaccount` (
  `wxaccountid` int(11) NOT NULL AUTO_INCREMENT,
  `openid` varchar(255) NOT NULL DEFAULT '' COMMENT '用户的标识，对当前公众号唯一',
  `nickname` varchar(32) DEFAULT NULL COMMENT '昵称',
  `sex` int(2) DEFAULT NULL COMMENT '性别，1男性，2女性，0未知',
  `city` varchar(127) DEFAULT NULL COMMENT '所在城市',
  `country` varchar(127) DEFAULT NULL COMMENT '所在国家',
  `province` varchar(127) DEFAULT NULL COMMENT '所在省份',
  `language` varchar(127) DEFAULT NULL COMMENT '语言，简体中文为zh_CN',
  `headimgurl` varchar(255) DEFAULT NULL COMMENT '头像',
  `subscribe_time` datetime DEFAULT NULL COMMENT '用户关注时间，为时间戳。如果用户曾多次关注，则取最后关注时间',
  `subscribe` int(11) DEFAULT NULL COMMENT '用户是否订阅该公众号标识，1 已关注 0 未关注',
  `unionid` varchar(255) DEFAULT NULL COMMENT '只有在用户将公众号绑定到微信开放平台帐号后，才会出现该字段',
  `remark` varchar(127) DEFAULT NULL COMMENT '公众号运营者对粉丝的备注',
  `groupid` varchar(255) DEFAULT NULL COMMENT '用户所在的分组ID',
    PRIMARY KEY (`wxaccountid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;